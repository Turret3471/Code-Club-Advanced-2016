var value = 0;
function button1() {
  
}